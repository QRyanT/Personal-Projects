<!DOCTYPE html>
<html>
<head>
    <!-- Program by Ryan Quiring 
    This page will allow the user to see the saved articles from any of the 3 RSS Feeds-->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Saved Information</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" />
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script></head>
    <script>
        function change(button)
        {
            var elem = button;
            if (elem.innerHTML == "See More")
            {
                elem.innerHTML = "See Less";
            } 
            else elem.innerHTML = "See More";
        }
   </script>
    <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="RSSHome.php">Ryan's Really Simple RSS</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-item nav-link" href="RSSCars.php">View Automobile Feed</a>
                <a class="nav-item nav-link" href="RSSOverwatch.php">View Overwatch Feed</a>
                <a class="nav-item nav-link" href="RSSProgrammer.php">View Programming Feed</a>
                <a class="nav-item nav-link" href="RSSSaved.php">View Saved Items</a>
            </div>
        </div>
    </nav>
    <form>
    <div class="col-md-11">    
    <h1 class="display-4">Saved Items</h1>
    <p>
    <button type='submit'  class='btn btn-info' value="Cars" id="Cars" name="Cars"
    >View Automobile Articles</button>
    <button type='submit' style='margin-left:8px;' class='btn btn-info' value="Overwatch" id="Overwatch" name="Overwatch"
    >View Overwatch Articles</button>
    <button type='submit' style='margin-left:8px;' class='btn btn-info' value="Programmer" id="Programmer" name="Programmer"
    >View Programmer Articles</button>
    </p>
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'GET')
        {
            $SavedList = simplexml_load_file('XMLSaved.xml');

            if (isset($_GET['Cars'])) //print out cars articles
            {        
                printSavedCars($SavedList);
            }
            
            else if (isset($_GET['Overwatch'])) //print out Overwatch articles
            {
                printSavedOverwatch($SavedList);
            }
            else if (isset($_GET['Programmer'])) //print out programmer articles
            {
                printSavedProgrammer($SavedList);
            }
            else
            {
                echo ("<h3>Click an above link to view saved articles</h3>");

            }
        }

        function printSavedCars($SavedList)
        {
            echo "<h1 class='display-4'>" . "Saved Automobile Articles</h1><br />";

            //Needed for collapsibles.
            $collapseInt = 0;


            foreach ($SavedList->Cars->item as $item)
            {

                //Formats the date
                $date = $item->pubDate;
                $date = substr($date, 0, -15);

                $content = str_replace('width="1200"', 'width="1000"', $item->children('content', true));


                //Prints everything from item tags
                echo (
                    "<h3><a style='color:black' href = '" . $item->link . "'>" . $item->title . "</a></h3>" .
                    "<h5><small class='text-muted'>" . $item->description . "</small></h5>" 
                    . "  <p><a onclick='change(this)' class='btn btn-info' data-toggle='collapse'
                     href='#collapseExample" . $collapseInt  . "'" .
                     "role='button' id='seeMoreBtn" . $collapseInt . "' aria-expanded='false'
                      aria-controls='collapseExample" .  $collapseInt  . "'" .
                      "'>See More</a></p>"
                     . "<div class='collapse' 
                     id='collapseExample" . $collapseInt . "'>" .
                      "<div class='card card-body'>"
                    . $content . "</div></div><br />" .
                    "<img src='" . $item->children('media', true)->content->attributes() . "' width=1000 /><br />"
                    . "<small>Written by " . $item->author . " on " . $date . "</small>"
                    . "<hr />");

                $collapseInt++; //This is what keeps collapsibles together with their targets.
            }

        }

        function printSavedOverwatch($SavedList)
        {

            echo "<h1 class='display-4'>" . "Saved Overwatch Articles</h1><br />";

            foreach ($SavedList->Overwatch->entry as $item)
            {

                //Formats the date
                $date = $item->updated;
                $date = substr($date, 0, -15);


                //Prints everything from item tags
                echo (
                    "<h3><a style='color:black' href = '" . $item->id . "'>" . $item->title . "</a></h3>" .
                    "<h5><small class='text-muted'>" . $item->description . "</small></h5>" 
                    . $item->content 
                    . "<small>Written by " . $item->author->name . " on " . $date . "</small>"
                    . "<hr />");
            }
        }

        function printSavedProgrammer($SavedList)
        {
            echo "<h1 class='display-4'>" . "Saved Programmer Articles</h1><br />";

            $collapseInt = 0;

            foreach ($SavedList->Programmer->item as $item)
            {

                //Formats the date
                $date = $item->pubDate;
                $date = substr($date, 0, -15);


                //Prints everything from item tags
                echo (
                    "<h3><a style='color:black' href = '" . $item->link . "'>" . $item->title . "</a></h3>" .
                    "<h5><small class='text-muted'>" . $item->description . "</small></h5>" 
                    . "  <p><a onclick='change(this)' class='btn btn-info' data-toggle='collapse'
                     href='#collapseExample" . $collapseInt  . "'" .
                     "role='button' id='seeMoreBtn" . $collapseInt . "' aria-expanded='false'
                      aria-controls='collapseExample" .  $collapseInt  . "'" .
                      "'>See More</a>
                      </p>"
                     . "<div class='collapse' 
                     id='collapseExample" . $collapseInt . "'>" .
                      "<div class='card card-body'>"
                    . $item->children('content', true) . "</div></div>" 
                    . "<small>Written by " .  $item->children('dc', true) . " on " . $date . "</small>"
                    . "<hr />");

                $collapseInt++; //This is what keeps collapsibles together with their targets.
            }
        }
        ?> 
        </div>
    </form>

</body>
</html>


