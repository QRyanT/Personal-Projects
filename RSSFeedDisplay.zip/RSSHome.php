<!DOCTYPE html>
<html>
<head>
    <!-- Home Page 
     Program by Ryan Quiring 
     This program will display 3 RSS feeds from different sources.
     This program will also allow the user to "save" articles which will be stored in an xml document.
     All users will share a singular xml document, so all users will see all saved articles.
    -->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" />
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script></head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="RSSHome.php">Ryan's Really Simple RSS</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-item nav-link" href="RSSCars.php">View Automobile Feed</a>
                <a class="nav-item nav-link" href="RSSOverwatch.php">View Overwatch Feed</a>
                <a class="nav-item nav-link" href="RSSProgrammer.php">View Programming Feed</a>
                <a class="nav-item nav-link" href="RSSSaved.php">View Saved Items</a>
            </div>
        </div>
    </nav>
    <form class="container-fluid">

    <div class="col-md-11">


    <h1 align=center class="display-4">Ryan's Really Simple RSS</h1>
    <br />
    
    <div class="row">
        <div class="col-sm-4">
            <div class="card" style="width: 18rem;">
                <div class="card-body">
                    <h5 class="card-title">View Automobile Feed!</h5>
                    <p class="card-text">Go head over to the feed to view some awesome articles curated by the experts at Car & Driver!</p>
                    <a href="RSSCars.php" class="btn btn-primary">View Now</a>
                </div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="card" style="width: 18rem;">
                <div class="card-body">
                    <h5 class="card-title">View Programming Feed!</h5>
                    <p class="card-text">Go see the feed to view some awesome conversations written by the craziest of all programmers!</p>
                    <a href="RSSProgrammer.php" class="btn btn-primary">View Now</a>
                </div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="card" style="width: 18rem;">
                <div class="card-body">
                    <h5 class="card-title">View Overwatch Feed!</h5>
                    <p class="card-text">Go catch up with the latest Overwatch news all created by your friends from SB Nation!</p>
                    <a href="RSSOverwatch.php" class="btn btn-primary">View Now</a>
                </div>
            </div>
            </div>
        </div>


        
        </div>
        <hr />

    </form>
    

</body>
</html>


