<!DOCTYPE html>
<html>
<head>
    <!-- Program by Ryan Quiring 
    This page will display the Car & Driver RSS Feed-->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Car Information</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" />
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script></head>
    <script>
        function change(button)
        {
            var elem = button;
            if (elem.innerHTML == "See More")
            {
                elem.innerHTML = "See Less";
            } 
            else elem.innerHTML = "See More";
        }
   </script>
    <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="RSSHome.php">Ryan's Really Simple RSS</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-item nav-link" href="RSSCars.php">View Automobile Feed</a>
                <a class="nav-item nav-link" href="RSSOverwatch.php">View Overwatch Feed</a>
                <a class="nav-item nav-link" href="RSSProgrammer.php">View Programming Feed</a>
                <a class="nav-item nav-link" href="RSSSaved.php">View Saved Items</a>
            </div>
        </div>
    </nav>
    <form class="container-fluid">
        <div class="col-md-11">
    
        <?php
            $carsList = simplexml_load_file('https://howdyfeeds-prod.s3.amazonaws.com/generic-autos-us/car-and-driver-rss.xml');

            


            echo "<h1 class='display-4'>" . "<a style='color:black' href= '" . $carsList->channel->link . "' >"
            . $carsList->channel->title . "</a></h1>";
            echo "<h3><small class='text-muted'>" . $carsList->channel->description . "</small></h3><br />";

            //Needed for collapsibles.
            $collapseInt = 0;


            foreach ($carsList->channel->item as $item)
            {

                //Formats the date
                $date = $item->pubDate;
                $date = substr($date, 0, -15);

                //Go through the feed and make the images not gigantic.
                $content = str_replace('width="1200"', 'width="1000"', $item->children('content', true));

                // html heading information to be echoed
                $heading =  "<h3><a style='color:black' href = '" . $item->link . "'>" . $item->title . "</a></h3>" .
                "<h5><small class='text-muted'>" . $item->description . "</small></h5>";

                //html content information to be echoed
                $articleBody =  "<p><a onclick='change(this)' class='btn btn-info' data-toggle='collapse'
                href='#collapseExample" . $collapseInt  . "'" .
                "role='button' id='seeMoreBtn" . $collapseInt . "' aria-expanded='false'
                 aria-controls='collapseExample" .  $collapseInt  . "'" .
                 "'>See More</a><button type='submit'  
                 style='margin-left:8px;' class='btn btn-info' value='". $item->title . "'
                 id='btn" . $collapseInt . "' name='btn" . $collapseInt . "'/>Save Article</button></p>"
                . "<div class='collapse' 
                id='collapseExample" . $collapseInt . "'>" .
                 "<div class='card card-body'>"
               . $content . "</div></div><br />";

               //html image to be echoed
               $image = "<img src='" . $item->children('media', true)->content->attributes() . "' width=1000 /><br />";

               //html footer information to be echoed
               $footer = "<small>Written by " . $item->author . " on " . $date . "</small>"
               . "<hr />";

                //Print html
                echo ($heading . $articleBody . $image . $footer);

                $collapseInt++; //This is what keeps collapsibles together with their targets.
            }

            $oldDate = $carsList->channel->lastBuildDate;
            $oldDate = substr($oldDate, 0, -15);

            //Prints out footer information
            echo "<small class='text-muted'>" . $carsList->channel->copyright . " on " .
            $oldDate . "</small>";

            //if the save article button is pressed, save the article
            if ($_SERVER['REQUEST_METHOD'] == 'GET')
            {
                $savedDocument = new DOMDocument();
                $savedDocument->load("XMLSaved.xml");

                //Go through and find the pressed button
                $articleTitle ="";

                for($x = 0; $x <= $collapseInt; $x++)
                {
                    $buttonID = 'btn' . $x;

                    if(isset($_GET[$buttonID]))
                    {

                        $articleTitle = $_GET[$buttonID];
                    }
                }
                
                //Go through and find the item with that title
                $collapseInt=0;
                foreach ($carsList->channel->item as $item)
                {
                    if ($articleTitle == $item->title)
                    {
                        $itemDOM = dom_import_simplexml($item);                 //Save item
                        $rootElement = $savedDocument->documentElement;

                        foreach ($rootElement->childNodes AS $type)
                        {
                            if ($type->nodeName == "Cars")
                            {
                                $type->appendChild($savedDocument->importNode($itemDOM, true));
                                break;
                            }
                        }
                        break;
                    }
                    
                    $collapseInt++;
                }
                $savedDocument->save("XMLSaved.xml");
            }            
        ?> 
        </div>
    </form>

</body>
</html>


