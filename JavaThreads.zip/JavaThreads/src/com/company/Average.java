package com.company;

import java.util.ArrayList;
//This class will calculate the average value of a given array.
public class Average implements Runnable
{
    private ArrayList<Integer> values;
    private static double Average;

    public Average(ArrayList<Integer> values) {
        this.values = values;
        Average = 0;
    }

    public static double getAverage() {
        return Average;
    }

    @Override
    public void run()
    {
        int total = 0;
        for (int i=0; i<values.size(); i++)
        {
            total += values.get(i);
        }

        Average =  (double) total / values.size();

    }
}
