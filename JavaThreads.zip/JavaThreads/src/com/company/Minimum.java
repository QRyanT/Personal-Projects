package com.company;

import java.util.ArrayList;

//This class will calculate the minimum value of a given array.
public class Minimum implements Runnable {
    private ArrayList<Integer> values;
    private static int Minimum;

    public int getMinimum() {
        return Minimum;
    }

    public Minimum(ArrayList<Integer> values) {
        this.values = values;
        Minimum = Integer.MAX_VALUE;

    }
    @Override
    public void run()
    {
        for (int i=0; i<values.size(); i++)
        {
            if (values.get(i) < Minimum)
            {
                Minimum = values.get(i);
            }
        }
    }
}
