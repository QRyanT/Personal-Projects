package com.company;

import java.util.ArrayList;

//This class will calculate the maximum value of a given array.

public class Maximum implements Runnable {
    private ArrayList<Integer> values;
    private static int Maximum;

    public int getMaximum() {
        return Maximum;
    }

    public Maximum(ArrayList<Integer> values) {
        this.values = values;

        Maximum = Integer.MIN_VALUE;
    }
    @Override
    public void run()
    {
        for (int i=0; i<values.size(); i++)
        {
            if (values.get(i) > Maximum)
            {
                Maximum = values.get(i);
            }
        }
    }
}
