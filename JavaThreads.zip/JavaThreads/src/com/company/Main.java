package com.company;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Random;
/* Ryan Quiring Threads Program
 This is an extremely simple program showcasing threads working concurrently, but obviously does not involve any deadlock/critical section computations.
 This will create an array of a size provided by the user, and then calculate the average, min, and max using threads. */
public class Main {

    private static ArrayList<Integer> values;

    public static void main(String[] args) throws InterruptedException {

        int numValues = Integer.parseInt(JOptionPane.showInputDialog("Please enter the number of values you would like to generate:")); //get size of array
        values= new ArrayList<Integer>();
        Random rand = new Random(2018);
        for (int i=0; i< numValues; i++)
        {

            values.add(rand.nextInt(1000)); //add random values with 2018 seed
        }

        Average Average = new Average(values);
        Minimum Min = new Minimum(values);
        Maximum Max = new Maximum(values);

        Thread t1 = new Thread(Average);
        Thread t2 = new Thread(Min);
        Thread t3 = new Thread(Max);

        t1.start();
        t2.start();
        t3.start();

        t1.join();
        t2.join();
        t3.join();

        String output = "The values submitted were:\n";

        for (int i=0; i<values.size(); i++)
        {
            output += values.get(i);
            output += " ";
        }

        output += "\nAnd, the values returned were:\n" +
                "Average = " + com.company.Average.getAverage() + "" +
                "\nMinimum = " + Min.getMinimum() + "" +
                "\nMaximum = " + Max.getMaximum();

        JOptionPane.showMessageDialog(null, output);

    }
}
